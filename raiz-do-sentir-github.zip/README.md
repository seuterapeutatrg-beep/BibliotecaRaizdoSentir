# Raiz do Sentir — Site de Vendas

Arquivos prontos para GitHub Pages.

## Publicar
1. Crie ou abra seu repositório no GitHub.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Em Settings > Pages, publique a branch principal pela raiz `/`.
4. Aguarde o GitHub gerar o endereço público.

O `index.html` já contém as imagens incorporadas e os links de checkout da Kiwify.
